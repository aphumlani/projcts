import java.util.Scanner;

public class RockPaperScissors {
    public static void main(String[] args) {
        int PlayerOneCount = 0, PlayerTwoCount = 0;
        Scanner in = new Scanner(System.in);
        int PlayerOne = 0;
        int PlayerTwo = 0;
        //int tie = 1;
        while (PlayerOne != 4 || PlayerTwo != 4) {
            System.out.println("Player One: Choose your weapon!");
            PlayerOne = in.nextInt();
            if(PlayerOne == 4 || PlayerTwo == 4){

                if (PlayerOneCount == PlayerTwoCount){
                    System.out.println("Player One and Player Two are tied with " + PlayerOneCount  + " points.");

                }
                if (PlayerOneCount > PlayerTwoCount){
                    System.out.println("The winner is Player One with " + PlayerOneCount + " points.");

                }
                if (PlayerOneCount < PlayerTwoCount){
                    System.out.println("The winner is Player Two with " + PlayerTwoCount + " points.");
                }

                System.out.println("Quitting");
                break;
            }
            System.out.println("Good choice!");
            System.out.println("Player Two: Choose your weapon!");
            PlayerTwo = in.nextInt();
            System.out.println("Good choice!");

            if (PlayerOne == 1) {
                System.out.println("Player One chose: rock");
            } else if (PlayerOne == 2) {
                System.out.println("Player One chose: paper");
            } else if (PlayerOne == 3) {
                System.out.println("Player One chose: scissors");
            }
            if (PlayerTwo == 1) {
                System.out.println("Player Two chose: rock");
            } else if (PlayerTwo == 2) {
                System.out.println("Player Two chose: paper");
            } else if (PlayerTwo == 3) {
                System.out.println("Player Two chose: scissors");
            }

            if (PlayerOne == PlayerTwo) {
                System.out.println("It's a draw!");
                System.out.println("The score is now: " + PlayerOneCount + " - " + PlayerTwoCount);
                 //tie = PlayerOneCount + PlayerTwoCount;
            } else if (PlayerOne == 1 && PlayerTwo == 2) {
                System.out.println("Player Two Wins!");
                PlayerTwoCount += 1;
                System.out.println("The score is now: " + PlayerOneCount + " - " + PlayerTwoCount);
            }
            else if (PlayerOne == 1 && PlayerTwo == 3) {
                System.out.println("Player One Wins!");
                PlayerOneCount += 1;
                System.out.println("The score is now: " + PlayerOneCount + " - " + PlayerTwoCount);
            }
            else if (PlayerOne == 2 && PlayerTwo == 1) {
                System.out.println("Player One Wins!");
                PlayerOneCount += 1;
                System.out.println("The score is now: " + PlayerOneCount + " - " + PlayerTwoCount);
            }
            else if (PlayerOne == 2 && PlayerTwo == 3) {
                System.out.println("Player Two Wins!");
                PlayerTwoCount += 1;
                System.out.println("The score is now: " + PlayerOneCount + " - " + PlayerTwoCount);
            }
            else if (PlayerOne == 3 && PlayerTwo == 1) {
                System.out.println("Player Two Wins!");
                PlayerTwoCount += 1;
                System.out.println("The score is now: " + PlayerOneCount + " - " + PlayerTwoCount);
            }
            else if (PlayerOne == 3 && PlayerTwo == 2) {
                System.out.println("Player One Wins!");
                PlayerOneCount += 1;
                System.out.println("The score is now: " + PlayerOneCount + " - " + PlayerTwoCount);
            }
        }
    }
}
