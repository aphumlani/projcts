import java.util.Scanner;

public class Hangman {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String[] words = new String[1];
        String word = "";
        int count = 0;
        System.out.println("Player One, enter a word:");
        String player1_word = sc.next();
        for (int i = 0; i < words.length; i++) {
            words[i] = player1_word;
            word = words[i];
        }
        String phura = new String(new char[word.length()]).replace("\0", "_");
        System.out.println(phura);
        int life = 8;
        while (count < 8 && phura.contains("_")) {
            System.out.println("Player Two, you have " + life + " guesses left. Enter a guess:");
            String guess = sc.next();
            String new_underscore = "";
            for (int i = 0; i < word.length(); i++) {
                if (word.charAt(i) == guess.charAt(0)) {
                    new_underscore += guess.charAt(0);
                } else if (phura.charAt(i) != '_') {
                    new_underscore += word.charAt(i);
                } else {
                    new_underscore += "_";
                }
            }
            if(phura.contains(String.valueOf(guess))) {
                System.out.println("You have already guessed that letter.");
            }
            else if (phura.equals(new_underscore)) {
                life--;
                count++;
                if(count < 8){
                    System.out.println(phura);
                }
            } else {
                phura = new_underscore;
                System.out.println(phura);
            }
            if (phura.equals(word)) {
                System.out.println("Game over. Player Two wins!");
            }
            else if(count == 8){
                System.out.println("Game over. Player One wins! The word was: " + word);
            }
        }
        sc.close();
    }
}
